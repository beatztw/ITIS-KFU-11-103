import java.awt.Color;
import java.awt.event.MouseEvent;

import acm.graphics.GImage;
import acm.graphics.GLabel;
import acm.graphics.GObject;
import acm.graphics.GOval;
import acm.graphics.GRect;
import acm.program.GraphicsProgram;
import acm.util.RandomGenerator;


public class PAINTBALL extends GraphicsProgram{
	RandomGenerator rand= new RandomGenerator();
	private static final int radx=160;
	private static final int rady=20;
	private static final int RAD=20;
	private static final int DISTANCE=17;
	private static final int nrows=5;
	private static final int ncols=4;
	boolean w=false;
	GLabel b;
	GLabel a;
	GOval circle;
	GRect rec;
	GRect rec1;
	GImage img;
	GImage img1;
	int dx=5;
	int dy=5;
	int score=0;
	public void run(){
		addMouseListeners();
		rec=new GRect(getWidth()/2-RAD/2,getHeight()-RAD/2,radx,rady);
		add(rec);
		drawCircle(RAD,getWidth()/2-RAD/2,getHeight()/2-RAD/2,Color.BLUE);
		drawKp();
		b=new GLabel("",0,getHeight());
		b.setFont("Arial-25");
		add(b);
		while(w==false){
			b.setLabel(Integer.toString(score));
			checkObjects();
			cheakwalls();
			circle.move(dx, dy);
			pause(15);
			if(score==ncols*nrows){
			removeAll();
			img1 = new GImage("C://Users//innopolis//Desktop//win.jpg");
			
			img1.setSize(getWidth(),getHeight()+35);
			add(img1);
			break;
		}
		}
		
		
		
		
	}
      private void drawCircle(int rad, int x, int y, Color a){
    	  circle=new GOval(x,y,rad,rad);
    	  circle.setFilled(true);
    	  circle.setColor(a);
    	  add(circle);
      }
      private void cheakwalls(){
    	  if(circle.getX()>getWidth()-RAD){
    		  dx=-4;
    	  }
    	  if(circle.getX()<1){
    		  dx=4;
    	  }
    	  if(circle.getY()>getHeight()-RAD){
    		  removeAll();
    		  img = new GImage("C://Users//innopolis//Desktop//gm.png");
    			
    			img.setSize(getWidth(),getHeight());
    			add(img);
    		  w=true;
    	  }
    	  if(circle.getY()<1){
    		  dy=4;
    	  }
    	  
      }
      public void mouseMoved(MouseEvent e){
    	  
    	
    	if(e.getX()<getWidth()-radx/2&&e.getX()>radx/2){
    	rec.setLocation(e.getX()-radx/2,getHeight()-rady/2-40);
    	}
    	rec.setFilled(true);
		rec.setFillColor(Color.CYAN);
      }
      private void drawKp(){
    	  int bx=0;
    	  int by=0;
    	  for(int i=0;i<ncols;i++){
    		  for(int j=0;j<nrows;j++){
    			  rec1=new GRect(radx,rady);
    			  bx=DISTANCE+i*(radx+DISTANCE);
    			  by=DISTANCE+j*(rady+DISTANCE);
    			  rec1.setLocation(bx,by);
    			  rec1.setFilled(true);
    	  rec1.setFillColor(rand.nextColor());
    	  add(rec1);
    		  }
    	  }
    	  
    	   }
      private GObject getCollidingObject(){
    	  double left=circle.getX();
    	  double right=circle.getX()+RAD;
    	  double buttom=circle.getY();
    	  double top=circle.getY()+RAD;
    	  
    	  GObject lefttop=getElementAt(left,top);
    	  if(lefttop!=null){
    		  return lefttop;
    	  }
    	  GObject leftbuttom=getElementAt(left,buttom);
    	  if(leftbuttom!=null){
    		  return leftbuttom;
    	  }
    	  GObject righttop=getElementAt(right,top);
    	  if(righttop!=null){
    		  return righttop;
    	  }
    	  GObject rightbuttom=getElementAt(right,buttom);
    	  if(rightbuttom!=null){
    		  return rightbuttom;
    	  }
    	  return null;
      }
      private void checkObjects(){
    	  GObject elem=getCollidingObject();
    	  if(elem!=null){
    		  if(elem!=rec){
    			  remove(elem);
    			  score++;
    			  dy=-dy;
    		  }
    		  else {
    			  dy=-dy;
    		  }
    	  }
    	  
      }
}
