import java.awt.event.MouseEvent;

import acm.graphics.GRect;
import acm.program.GraphicsProgram;
import acm.util.RandomGenerator;


public class Task1 extends GraphicsProgram{
	RandomGenerator rand= new RandomGenerator();
	private static final int N=25;
	GRect[] a;
	public void run(){
		addMouseListeners();
		a=new GRect[N];
		for(int i=0;i<a.length; i++){
		 a[i]= new GRect(26,26);
		 a[i].setLocation(rand.nextInt(getWidth()-26),rand.nextInt(getHeight()-26));
		 add(a[i]);
		}
		while(true){
			for(int i=0;i<a.length;i++){
				a[i].move(rand.nextInt(-3,3),rand.nextInt(-3,3));
			}
			pause(1000/24);
		}
	}
	public void mousePressed(MouseEvent e){
		
		for(int i=0;i<a.length;i++){
			a[i].setLocation(e.getX()-13,e.getY()-13);
			a[i].setFilled(true);
			a[i].setFillColor(rand.nextColor());
		}

	}

}
